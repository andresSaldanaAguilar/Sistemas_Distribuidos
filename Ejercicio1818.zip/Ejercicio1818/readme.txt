Correr programa:
1.-correr script db.sql
2.-correr el proyecto web
3.-en el web service, dar click en "test web service"
4.-servido :v